//
//  ViewController.swift
//  blukiiSK_Demo
//
//  Version 1.2, complies to blukiiSK Version 1.0
//
//  Copyright (c) 2016 Schneider Schreibgeräte GmbH
//  All rights reserved.

import UIKit

// ** **** **** **** **** **** **** **** **
// ************** Settings ****************
// ** **** **** **** **** **** **** **** **

// 0 -> Reset SmartKey configuration
// 1 -> Configurate/Authenticate in Conveninece-Mode
// 2 -> Configurate/Authenticate in Pairing-Mode
// 3 -> Configurate/Authenticate in Secure-Mode
let blukiiSK_Demo_Command:Int = 2

// SmartKey which will be used in the demo
let blukiiSK_Demo_SmartKeyID:String = "2471894DBB72"

// Pairing Key which will be set on the smartKey in the secure mode configuration
let blukiiSK_Demo_PairingKey:UInt32 = 123456

//Choose here if you already configurated your SmartKey
var configDone = false

// ** **** **** **** **** **** **** **** **
// ** **** **** **** **** **** **** **** **
// ** **** **** **** **** **** **** **** **


class ViewController: UIViewController, SKManagerDelegate{
    
    var _SKManager:SKManager!
    
    func blukiiSKDemoDone(){
        _SKManager.disconnectFromSmartKey()
        _SKManager.cancleSmartKeyRequest()
        _SKManager.delegate = nil
        print("\n****************************")
        print("**   blukiiSK_Demo done   **")
        print("****************************")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        print("\n******************************")
        print("**   start blukiiSK_Demo    **")
        print("******************************")
        
        print("**   iOS-Version \(NSProcessInfo.processInfo().operatingSystemVersionString)    **")
        
        _SKManager = SKManager.sharedManager() as! SKManager
        _SKManager.delegate = self
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func SKManagerDidUpdateState(state: SKManagerStates) {
        print("SKManagerDidUpdateState : \(state)")
        
        if state == .Ready{
            _SKManager.resetSecuritySettings()
            _SKManager.requestSmartKeysWithTimeout(2000, repeated: true)
        }else{
            print("   Bluetooth needs to be turned on!")
        }
    }
    
    func SKManagerDidReceiveSmartKeys(keys: [AnyObject]!) {
        
        print("SKManagerDidReceiveSmartKeys: \(keys.count)")
        
        let smartkeys = keys as? Array<SmartKey>
        
        if(smartkeys != nil){
            
            var linkKey:SmartKey? = nil
            
            //Check here if the desired SmartKey is in the received list
            for sk in smartkeys! {
                
                print("    --> \(sk.ID)")
                
                if(sk.ID == blukiiSK_Demo_SmartKeyID){
                    linkKey = sk;
                }
            }
            
            if linkKey != nil {
                
                print("   Link SmartKey: \(linkKey!.ID)")
                
                //and then link the SmartKey to the app
                _SKManager.linkSmartKey(linkKey)
            }
        }
    }
    func SKManagerDidFindLinkedSmartKey(linkedKey: SmartKey!) {
        
        print("SKManagerDidFindLinkedSmartKey \(linkedKey)")
        
        if !configDone && !linkedKey.service{
            print("\n*\n** WARNING: Configuration of the SmartKey requires a power on reset of the SmartKey (Service-Mode)\n*\n")
        }else{
            _SKManager.connectToSmartKey(false)
        }
        
    }
    
    func SKManagerDidDisconnectFromSmartKey(reason: SKManagerDisconnectReasons) {
        
        switch(blukiiSK_Demo_Command){
        case 1:
            _SKManager.requestSmartKeysWithTimeout(2000, repeated: true)
            break
        case 2,3:
            _SKManager.connectToSmartKey(false)
            break
        default:
            print("No valid demo command selected")
            break
        }
    }
    func SKManagerLinkedSmartKeyReady() {
        print("SKManagerLinkedSmartKeyReady")
        
        if !configDone{
            switch blukiiSK_Demo_Command{
            case 0:
                
                _SKManager.resetConfig()
                print("   Resetting the configuration of SmartKey")
                break
            case 1:
                
                _SKManager.configurateConvenienceMode()
                print("   Start configuration of SmartKey with Convenience-Mode")
                break
            case 2:
                
                _SKManager.configuratePairingModeWithPairingKey(SKCommon.createPairingKey(blukiiSK_Demo_PairingKey))
                print("   Start configuration of SmartKey with Pairing-Mode and PairingKey:\(blukiiSK_Demo_PairingKey)")
                
                break
            case 3:
             
                _SKManager.configurateSecureModeWithPairingKey(SKCommon.createPairingKey(blukiiSK_Demo_PairingKey))
                print("   Start configuration of SmartKey with Secure-Mode and PairingKey:\(blukiiSK_Demo_PairingKey)")
                break
            default:
                print("   No valid demo command selected")
                break
            }
        }else{
            switch blukiiSK_Demo_Command{
            case 1:
                _SKManager.disconnectFromSmartKey()
                break
            case 2,3:
                _SKManager.initiateAuthenticationChallenge()
                print("   Starting authentication...")
                break
            default:
                break
            }
        }
    }
    
    func SKManagerDidUpdateBatteryLevel(level: UInt8) {
        print("SKManagerDidUpdateBatteryLevel \(level)")
    }

    func SKManagerDidFinishConfiguration(successful: Bool) {
        print("SKManagerDidFinishConfiguration");
        
        if successful{
            print("   Configuration successfully done...")
            configDone = true
        }else{
            print("   Configuration error or timeout...try it again.")
        }
    }
    
    func SKManagerDidResetSmartKeyConfig(successful: Bool) {
        print("SKManagerDidResetSmartKeyConfig successful:\(successful)")
        
        if(blukiiSK_Demo_Command == 0){
            
            if successful {
                configDone = true
                _SKManager.requestSmartKeysWithTimeout(3000, repeated: true)
            }else{
                print("   Reset configuration not completed...try to replace the battery")
            }
            

            self.blukiiSKDemoDone()
        }
    }
    func SKManagerDidUpdateAuthenticationState(state: SKManagerAuthenticationStates) {

        
        if blukiiSK_Demo_Command > 0{
            if state == .Successful{
                
                print("SKManagerDidUpdateAuthenticationState\n     \(_SKManager.linkedKey!)")
                
                if _SKManager.linkedKey.config == .Convenience{
                    print("   Authenticated with a SmartKey in ConvenienceMode...\n")
                }else if _SKManager.linkedKey.config == .Pairing{
                    print("   Authenticated with a SmartKey in Pairing-Mode...\n")
                }else if _SKManager.linkedKey.config == .Secure{
                    print("   Secure authentiation challenge successful passed...\n")
                }
                
            }else if state == .PairingFailed{
                print("   Pairing failed! \n")
            }else{
                print("   Authentication failed! Modified SmartKey?! \n")
            }
        
            blukiiSKDemoDone()
        }
    }
    
    func SKManagerDidDetectModifiedSmartKey(sk: SmartKey!) {
        print("SKManagerDidDetectModifiedSmartKey \(sk.ID)")
        blukiiSKDemoDone()
    }
}

